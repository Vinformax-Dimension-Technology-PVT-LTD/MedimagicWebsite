<?php

return [
    'sites' => [
        'default' => [
            'timezone' => 'Asia/Dubai',
        ],
    ],
];
